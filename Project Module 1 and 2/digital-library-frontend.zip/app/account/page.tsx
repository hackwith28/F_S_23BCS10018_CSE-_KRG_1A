"use client"

import useSWR from "swr"
import { jsonFetcher } from "@/lib/fetcher"
import type { AccountSummary } from "@/lib/types"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function AccountPage() {
  const { data } = useSWR<AccountSummary>("/api/account/summary", jsonFetcher)

  return (
    <div className="grid gap-6">
      <h1 className="text-2xl font-semibold">My Account</h1>
      <Tabs defaultValue="loans">
        <TabsList>
          <TabsTrigger value="loans">Loans</TabsTrigger>
          <TabsTrigger value="reservations">Reservations</TabsTrigger>
          <TabsTrigger value="fines">Fines</TabsTrigger>
        </TabsList>

        <TabsContent value="loans" className="grid gap-3">
          {(data?.loans || []).map((t) => (
            <Card key={t.id}>
              <CardContent className="p-4 flex items-center justify-between">
                <div className="text-sm">
                  <div>Book ID: {t.bookId}</div>
                  <div>Issued: {new Date(t.issueDate).toLocaleDateString()}</div>
                  <div>Due: {new Date(t.dueDate).toLocaleDateString()}</div>
                  {t.returnDate && <div>Returned: {new Date(t.returnDate).toLocaleDateString()}</div>}
                </div>
                {typeof t.fineAccrued === "number" && t.fineAccrued > 0 && (
                  <span className="text-sm">Fine: ₹{t.fineAccrued.toFixed(2)}</span>
                )}
              </CardContent>
            </Card>
          ))}
          {!data?.loans?.length && <p className="text-muted-foreground">No active loans.</p>}
        </TabsContent>

        <TabsContent value="reservations" className="grid gap-3">
          {(data?.reservations || []).map((r) => (
            <Card key={r.id}>
              <CardContent className="p-4 text-sm flex items-center justify-between">
                <div>
                  <div>Book ID: {r.bookId}</div>
                  <div>Queued: {new Date(r.queuedAt).toLocaleString()}</div>
                </div>
                <span className="text-muted-foreground text-xs">Reservation #{r.id}</span>
              </CardContent>
            </Card>
          ))}
          {!data?.reservations?.length && <p className="text-muted-foreground">No reservations.</p>}
        </TabsContent>

        <TabsContent value="fines">
          <Card>
            <CardHeader>
              <CardTitle>Outstanding Fines</CardTitle>
            </CardHeader>
            <CardContent className="text-2xl font-semibold">₹{(data?.finesDue || 0).toFixed(2)}</CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
