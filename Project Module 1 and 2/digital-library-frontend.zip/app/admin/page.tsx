"use client"

import useSWR, { mutate } from "swr"
import { jsonFetcher } from "@/lib/fetcher"
import type { Book, FinePolicy } from "@/lib/types"
import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { useToast } from "@/hooks/use-toast"

function useIsAdmin() {
  const [isAdmin, setIsAdmin] = useState(false)
  useEffect(() => {
    const role = window.localStorage.getItem("lms-role")
    setIsAdmin(role === "ADMIN")
  }, [])
  return isAdmin
}

export default function AdminPage() {
  const isAdmin = useIsAdmin()
  const { toast } = useToast()
  const { data: books } = useSWR<{ items: Book[] }>("/api/books?pageSize=100", jsonFetcher)
  const { data: policies } = useSWR<FinePolicy[]>("/api/fines/policies", jsonFetcher)
  const { data: defaulters } = useSWR<{ cardId: number; totalFine: number }[]>("/api/admin/defaulters", jsonFetcher)

  const [form, setForm] = useState({
    title: "",
    author: "",
    genre: "",
    year: "",
    isbn: "",
    publisher: "",
    language: "English",
  })

  async function addBook() {
    const res = await fetch("/api/books", {
      method: "POST",
      body: JSON.stringify({
        ...form,
        year: Number(form.year) || new Date().getFullYear(),
      }),
    })
    if (res.ok) {
      toast({ title: "Book added" })
      setForm({ title: "", author: "", genre: "", year: "", isbn: "", publisher: "", language: "English" })
      mutate("/api/books?pageSize=100")
    } else {
      toast({ title: "Error", description: await res.text(), variant: "destructive" })
    }
  }

  async function updatePolicy(p: FinePolicy) {
    const res = await fetch("/api/fines/policies", { method: "PUT", body: JSON.stringify(p) })
    if (res.ok) {
      toast({ title: "Policy updated" })
      mutate("/api/fines/policies")
    } else {
      toast({ title: "Error", description: await res.text(), variant: "destructive" })
    }
  }

  if (!isAdmin) {
    return (
      <p className="text-muted-foreground">
        You need ADMIN role to access this page. Use the Switch Role button in the header.
      </p>
    )
  }

  return (
    <div className="grid gap-6">
      <h1 className="text-2xl font-semibold">Admin Dashboard</h1>

      <section className="grid gap-3 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Add Book</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-3">
            {[
              { id: "title", label: "Title" },
              { id: "author", label: "Author" },
              { id: "genre", label: "Genre" },
              { id: "year", label: "Year" },
              { id: "isbn", label: "ISBN" },
              { id: "publisher", label: "Publisher" },
              { id: "language", label: "Language" },
            ].map((f) => (
              <div key={f.id} className="grid gap-2">
                <Label htmlFor={f.id}>{f.label}</Label>
                <Input
                  id={f.id}
                  value={(form as any)[f.id]}
                  onChange={(e) => setForm((prev) => ({ ...prev, [f.id]: e.target.value }))}
                />
              </div>
            ))}
            <Button onClick={addBook}>Create</Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Fine Policies</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-4">
            {(policies || []).map((p) => (
              <div key={p.id} className="grid gap-2 rounded-md border p-3 md:grid-cols-2">
                <div>User Type: {p.userType}</div>
                <div>Item Type: {p.itemType}</div>
                <div className="flex items-center gap-2">
                  <Label className="w-32">Rate (₹/day)</Label>
                  <Input
                    type="number"
                    value={p.rate}
                    onChange={(e) => updatePolicy({ ...p, rate: Number(e.target.value) })}
                  />
                </div>
                <div className="flex items-center gap-2">
                  <Label className="w-32">Grace (days)</Label>
                  <Input
                    type="number"
                    value={p.gracePeriod}
                    onChange={(e) => updatePolicy({ ...p, gracePeriod: Number(e.target.value) })}
                  />
                </div>
                <div className="flex items-center gap-2">
                  <Label className="w-32">Max Fine (₹)</Label>
                  <Input
                    type="number"
                    value={p.maxFine}
                    onChange={(e) => updatePolicy({ ...p, maxFine: Number(e.target.value) })}
                  />
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </section>

      <section className="grid gap-3">
        <Card>
          <CardHeader>
            <CardTitle>Defaulters</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-2">
            {(defaulters || []).map((d) => (
              <div key={d.cardId} className="flex items-center justify-between rounded-md border p-3">
                <span>Card #{d.cardId}</span>
                <span className="font-medium">₹{d.totalFine.toFixed(2)}</span>
              </div>
            ))}
            {!defaulters?.length && <p className="text-muted-foreground">No defaulters.</p>}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Books (latest)</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-2">
            {(books?.items || []).slice(0, 8).map((b) => (
              <div key={b.id} className="flex items-center justify-between rounded-md border p-3 text-sm">
                <div className="text-pretty">{b.title}</div>
                <div className="text-muted-foreground">{b.author}</div>
              </div>
            ))}
          </CardContent>
        </Card>
      </section>
    </div>
  )
}
