import type { Book, FinePolicy, Reservation, Review, Transaction } from "@/lib/types"

const nextIds = {
  book: 6,
  review: 1,
  txn: 1,
  reservation: 1,
}

export const books: Book[] = [
  {
    id: 1,
    title: "Clean Code",
    author: "Robert C. Martin",
    genre: "Technology",
    year: 2008,
    isbn: "9780132350884",
    publisher: "Prentice Hall",
    isAvailable: true,
    ratingAvg: 4.6,
    language: "English",
  },
  {
    id: 2,
    title: "The Pragmatic Programmer",
    author: "Andrew Hunt",
    genre: "Technology",
    year: 1999,
    isbn: "9780201616224",
    publisher: "Addison-Wesley",
    isAvailable: false,
    ratingAvg: 4.7,
    language: "English",
  },
  {
    id: 3,
    title: "Sapiens",
    author: "Yuval Noah Harari",
    genre: "Non-Fiction",
    year: 2011,
    isbn: "9780099590088",
    publisher: "Harvill Secker",
    isAvailable: true,
    ratingAvg: 4.5,
    language: "English",
  },
  {
    id: 4,
    title: "The Alchemist",
    author: "Paulo Coelho",
    genre: "Fiction",
    year: 1988,
    isbn: "9780061122415",
    publisher: "HarperCollins",
    isAvailable: true,
    ratingAvg: 4.2,
    language: "English",
  },
  {
    id: 5,
    title: "A Brief History of Time",
    author: "Stephen Hawking",
    genre: "Non-Fiction",
    year: 1988,
    isbn: "9780553380163",
    publisher: "Bantam Books",
    isAvailable: true,
    ratingAvg: 4.1,
    language: "English",
  },
]

export const reviews: Review[] = []

// Assume a single current user with cardId=1 for demo
export const currentCardId = 1

export const transactions: Transaction[] = [
  // example: { id: 1, bookId: 2, cardId: 1, issueDate: new Date().toISOString(), dueDate: new Date(Date.now()+ 14*86400000).toISOString() }
]

export const reservations: Reservation[] = []

export const finePolicies: FinePolicy[] = [
  { id: 1, userType: "MEMBER", itemType: "BOOK", rate: 5, gracePeriod: 2, maxFine: 500 },
  { id: 2, userType: "ADMIN", itemType: "BOOK", rate: 0, gracePeriod: 7, maxFine: 0 },
]

// helpers
export function nextBookId() {
  return nextIds.book++
}
export function nextReviewId() {
  return nextIds.review++
}
export function nextTxnId() {
  return nextIds.txn++
}
export function nextReservationId() {
  return nextIds.reservation++
}
