import { finePolicies } from "../_data/store"

export function calculateFine(userType: "MEMBER" | "ADMIN", daysLate: number) {
  const policy = finePolicies.find((p) => p.userType === userType) || finePolicies[0]
  const effectiveDays = Math.max(0, daysLate - policy.gracePeriod)
  const raw = effectiveDays * policy.rate
  return Math.min(raw, policy.maxFine)
}
