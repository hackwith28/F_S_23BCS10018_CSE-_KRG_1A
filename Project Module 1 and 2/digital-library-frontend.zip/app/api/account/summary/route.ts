import { NextResponse } from "next/server"
import { currentCardId, reservations, transactions } from "../../_data/store"

export async function GET() {
  const loans = transactions
    .filter((t) => t.cardId === currentCardId)
    .slice(-20)
    .reverse()
  const resv = reservations
    .filter((r) => r.cardId === currentCardId)
    .slice(-20)
    .reverse()
  const finesDue = loans.reduce((sum, t) => sum + (t.fineAccrued || 0), 0)
  return NextResponse.json({ loans, reservations: resv, finesDue })
}
