import { NextResponse } from "next/server"
import { transactions } from "../../_data/store"

export async function GET() {
  const map = new Map<number, number>()
  for (const t of transactions) {
    if (t.fineAccrued && t.fineAccrued > 0) {
      map.set(t.cardId, (map.get(t.cardId) || 0) + t.fineAccrued)
    }
  }
  const list = Array.from(map.entries()).map(([cardId, totalFine]) => ({ cardId, totalFine }))
  return NextResponse.json(list)
}
