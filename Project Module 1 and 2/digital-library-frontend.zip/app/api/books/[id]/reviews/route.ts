import { NextResponse } from "next/server"
import { nextReviewId, reviews } from "../../../_data/store"

export async function GET(_req: Request, ctx: { params: { id: string } }) {
  const bookId = Number(ctx.params.id)
  return NextResponse.json(reviews.filter((r) => r.bookId === bookId))
}

export async function POST(req: Request, ctx: { params: { id: string } }) {
  const bookId = Number(ctx.params.id)
  const body = await req.json()
  const review = {
    id: nextReviewId(),
    bookId,
    userId: 1,
    rating: Number(body.rating) || 5,
    comment: String(body.comment || ""),
    createdAt: new Date().toISOString(),
  }
  reviews.unshift(review)
  return NextResponse.json(review, { status: 201 })
}
