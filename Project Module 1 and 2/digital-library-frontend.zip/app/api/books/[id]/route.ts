import { NextResponse } from "next/server"
import { books } from "../../_data/store"

export async function GET(_req: Request, ctx: { params: { id: string } }) {
  const id = Number(ctx.params.id)
  const book = books.find((b) => b.id === id)
  if (!book) return new NextResponse("Not found", { status: 404 })
  return NextResponse.json(book)
}

export async function PATCH(req: Request, ctx: { params: { id: string } }) {
  const id = Number(ctx.params.id)
  const body = await req.json()
  const idx = books.findIndex((b) => b.id === id)
  if (idx === -1) return new NextResponse("Not found", { status: 404 })
  books[idx] = { ...books[idx], ...body }
  return NextResponse.json(books[idx])
}

export async function DELETE(_req: Request, ctx: { params: { id: string } }) {
  const id = Number(ctx.params.id)
  const idx = books.findIndex((b) => b.id === id)
  if (idx === -1) return new NextResponse("Not found", { status: 404 })
  books.splice(idx, 1)
  return new NextResponse(null, { status: 204 })
}
