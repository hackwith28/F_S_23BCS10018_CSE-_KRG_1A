import { NextResponse } from "next/server"
import { books, nextBookId } from "../_data/store"

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url)
  const page = Number(searchParams.get("page") || "1")
  const pageSize = Number(searchParams.get("pageSize") || "12")
  const q = (searchParams.get("q") || "").toLowerCase()
  const genre = searchParams.get("genre") || ""
  const language = searchParams.get("language") || ""
  const available = searchParams.get("available") || ""

  const filtered = books.filter((b) => {
    const matchesQ =
      !q || b.title.toLowerCase().includes(q) || b.author.toLowerCase().includes(q) || b.isbn.toLowerCase().includes(q)
    const matchesGenre = !genre || genre === "All" || b.genre === genre
    const matchesLang = !language || language === "All" || b.language === language
    const matchesAvail =
      !available ||
      available === "Any" ||
      (available === "Available" && b.isAvailable) ||
      (available === "CheckedOut" && !b.isAvailable)
    return matchesQ && matchesGenre && matchesLang && matchesAvail
  })

  const total = filtered.length
  const start = (page - 1) * pageSize
  const items = filtered.slice(start, start + pageSize)
  return NextResponse.json({ items, total, page, pageSize })
}

export async function POST(req: Request) {
  const body = await req.json()
  const id = nextBookId()
  const book = {
    id,
    title: String(body.title || "Untitled"),
    author: String(body.author || "Unknown"),
    genre: String(body.genre || "General"),
    year: Number(body.year) || new Date().getFullYear(),
    isbn: String(body.isbn || id.toString().padStart(10, "0")),
    publisher: String(body.publisher || "N/A"),
    isAvailable: true,
    ratingAvg: 0,
    language: String(body.language || "English"),
  }
  books.unshift(book)
  return NextResponse.json(book, { status: 201 })
}
