import { NextResponse } from "next/server"
import { finePolicies } from "../../_data/store"

export async function GET() {
  return NextResponse.json(finePolicies)
}

export async function PUT(req: Request) {
  const body = await req.json()
  const idx = finePolicies.findIndex((p) => p.id === body.id)
  if (idx === -1) return new NextResponse("Not found", { status: 404 })
  finePolicies[idx] = { ...finePolicies[idx], ...body }
  return NextResponse.json(finePolicies[idx])
}
