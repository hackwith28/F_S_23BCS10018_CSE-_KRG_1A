import { NextResponse } from "next/server"
import { currentCardId, nextReservationId, reservations } from "../_data/store"

export async function GET() {
  return NextResponse.json(reservations.filter((r) => r.cardId === currentCardId))
}

export async function POST(req: Request) {
  const body = await req.json()
  const reservation = {
    id: nextReservationId(),
    bookId: Number(body.bookId),
    cardId: currentCardId,
    queuedAt: new Date().toISOString(),
  }
  reservations.push(reservation as any)
  return NextResponse.json(reservation, { status: 201 })
}

export async function DELETE(req: Request) {
  const { searchParams } = new URL(req.url)
  const id = Number(searchParams.get("id"))
  const idx = reservations.findIndex((r) => r.id === id && r.cardId === currentCardId)
  if (idx === -1) return new NextResponse("Not found", { status: 404 })
  reservations.splice(idx, 1)
  return new NextResponse(null, { status: 204 })
}
