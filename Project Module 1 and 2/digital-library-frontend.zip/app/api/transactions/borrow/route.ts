import { NextResponse } from "next/server"
import { books, currentCardId, nextTxnId, transactions } from "../../_data/store"

export async function POST(req: Request) {
  const body = await req.json()
  const bookId = Number(body.bookId)
  const b = books.find((x) => x.id === bookId)
  if (!b) return new NextResponse("Book not found", { status: 404 })
  if (!b.isAvailable) return new NextResponse("Book not available", { status: 409 })

  b.isAvailable = false
  const now = Date.now()
  const issue = new Date(now).toISOString()
  const due = new Date(now + 14 * 86400000).toISOString()
  const txn = { id: nextTxnId(), bookId, cardId: currentCardId, issueDate: issue, dueDate: due }
  transactions.push(txn as any)
  return NextResponse.json(txn, { status: 201 })
}
