import { NextResponse } from "next/server"
import { books, currentCardId, transactions } from "../../_data/store"
import { calculateFine } from "../../_lib/fines"

export async function POST(req: Request) {
  const body = await req.json()
  const bookId = Number(body.bookId)
  const txn = [...transactions]
    .reverse()
    .find((t) => t.bookId === bookId && t.cardId === currentCardId && !t.returnDate)
  if (!txn) return new NextResponse("Active transaction not found", { status: 404 })
  const book = books.find((b) => b.id === bookId)
  if (book) book.isAvailable = true

  const now = new Date()
  const due = new Date(txn.dueDate)
  const daysLate = Math.ceil((now.getTime() - due.getTime()) / 86400000)
  const fine = daysLate > 0 ? calculateFine("MEMBER", daysLate) : 0
  txn.returnDate = now.toISOString()
  txn.fineAccrued = fine

  const msg = fine > 0 ? `Returned with fine ₹${fine.toFixed(2)}` : "Returned on time"
  return NextResponse.json({ message: msg, transaction: txn })
}
