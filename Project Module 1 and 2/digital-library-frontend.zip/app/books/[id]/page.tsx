"use client"

import useSWR, { mutate } from "swr"
import { jsonFetcher } from "@/lib/fetcher"
import type { Book, Review } from "@/lib/types"
import { notFound, useParams } from "next/navigation"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useState } from "react"
import { useToast } from "@/hooks/use-toast"

export default function BookDetailPage() {
  const { id } = useParams<{ id: string }>()
  const { toast } = useToast()
  const { data: book } = useSWR<Book>(`/api/books/${id}`, jsonFetcher)
  const { data: reviews } = useSWR<Review[]>(`/api/books/${id}/reviews`, jsonFetcher)
  const [rating, setRating] = useState(5)
  const [comment, setComment] = useState("")

  if (!book) return null
  if (!book?.id) notFound()

  async function borrow() {
    const res = await fetch("/api/transactions/borrow", {
      method: "POST",
      body: JSON.stringify({ bookId: book.id }),
    })
    if (res.ok) {
      toast({ title: "Borrowed", description: "Enjoy your reading!" })
      mutate(`/api/books/${id}`)
      mutate("/api/account/summary")
    } else {
      toast({ title: "Cannot borrow", description: await res.text(), variant: "destructive" })
    }
  }

  async function returnBook() {
    const res = await fetch("/api/transactions/return", {
      method: "POST",
      body: JSON.stringify({ bookId: book.id }),
    })
    if (res.ok) {
      const data = await res.json()
      toast({ title: "Returned", description: data.message || "Thank you!" })
      mutate(`/api/books/${id}`)
      mutate("/api/account/summary")
    } else {
      toast({ title: "Cannot return", description: await res.text(), variant: "destructive" })
    }
  }

  async function reserve() {
    const res = await fetch("/api/reservations", {
      method: "POST",
      body: JSON.stringify({ bookId: book.id }),
    })
    if (res.ok) {
      toast({ title: "Reserved", description: "We will notify you when available." })
      mutate("/api/account/summary")
    } else {
      toast({ title: "Cannot reserve", description: await res.text(), variant: "destructive" })
    }
  }

  async function addReview() {
    const res = await fetch(`/api/books/${book.id}/reviews`, {
      method: "POST",
      body: JSON.stringify({ rating, comment }),
    })
    if (res.ok) {
      setComment("")
      toast({ title: "Review added" })
      mutate(`/api/books/${id}/reviews`)
    } else {
      toast({ title: "Error", description: await res.text(), variant: "destructive" })
    }
  }

  return (
    <div className="grid gap-6">
      <div className="grid gap-6 md:grid-cols-[200px_1fr]">
        <div className="relative h-64 w-full rounded-md border bg-card">
          <Image
            src={book.coverUrl || "/placeholder.svg?height=256&width=200&query=book%20cover"}
            alt={`${book.title} cover`}
            fill
            className="object-cover rounded-md"
          />
        </div>
        <div className="grid gap-2">
          <h1 className="text-2xl font-semibold text-pretty">{book.title}</h1>
          <p className="text-muted-foreground">Author: {book.author}</p>
          <p className="text-muted-foreground">
            Genre: {book.genre} • Year: {book.year}
          </p>
          <p className="text-muted-foreground">
            Publisher: {book.publisher} • ISBN: {book.isbn}
          </p>
          <div className="flex gap-2 pt-2">
            {book.isAvailable ? (
              <Button onClick={borrow}>Borrow</Button>
            ) : (
              <>
                <Button onClick={reserve}>Reserve</Button>
                <Button onClick={returnBook} variant="outline">
                  Return
                </Button>
              </>
            )}
          </div>
        </div>
      </div>

      <section className="grid gap-3">
        <h2 className="text-xl font-medium">Reviews</h2>
        <div className="grid gap-4 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>Write a review</CardTitle>
            </CardHeader>
            <CardContent className="grid gap-3">
              <Label htmlFor="rating">Rating</Label>
              <input
                id="rating"
                type="range"
                min={1}
                max={5}
                value={rating}
                onChange={(e) => setRating(Number(e.target.value))}
                aria-label="Rating"
              />
              <Label htmlFor="comment" className="sr-only">
                Comment
              </Label>
              <Textarea
                id="comment"
                placeholder="Share your thoughts"
                value={comment}
                onChange={(e) => setComment(e.target.value)}
              />
              <Button onClick={addReview}>Submit</Button>
            </CardContent>
          </Card>

          <div className="grid gap-3">
            {(reviews || []).map((r) => (
              <Card key={r.id}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <strong>★ {r.rating}</strong>
                    <span className="text-muted-foreground text-xs">{new Date(r.createdAt).toLocaleString()}</span>
                  </div>
                  <p className="mt-2 text-pretty">{r.comment}</p>
                </CardContent>
              </Card>
            ))}
            {!reviews?.length && <p className="text-muted-foreground">No reviews yet.</p>}
          </div>
        </div>
      </section>
    </div>
  )
}
