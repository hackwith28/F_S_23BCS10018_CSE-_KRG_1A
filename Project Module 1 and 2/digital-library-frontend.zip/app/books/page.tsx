"use client"

import useSWR from "swr"
import { jsonFetcher } from "@/lib/fetcher"
import type { Book, Paged } from "@/lib/types"
import { useSearchParams } from "next/navigation"
import { SearchFilters } from "@/components/search-filters"
import { BookCard } from "@/components/book-card"
import { Pagination, PaginationContent, PaginationItem, PaginationLink } from "@/components/ui/pagination"

export default function BooksPage() {
  const params = useSearchParams()
  const page = Number(params.get("page") || "1")
  const q = params.get("q") || ""
  const genre = params.get("genre") || ""
  const language = params.get("language") || ""
  const available = params.get("available") || ""
  const query = new URLSearchParams({ page: String(page), pageSize: "12" })
  if (q) query.set("q", q)
  if (genre) query.set("genre", genre)
  if (language) query.set("language", language)
  if (available) query.set("available", available)

  const { data } = useSWR<Paged<Book>>(`/api/books?${query.toString()}`, jsonFetcher)

  const totalPages = data ? Math.max(1, Math.ceil(data.total / data.pageSize)) : 1

  return (
    <div className="grid gap-6">
      <h1 className="text-2xl font-semibold text-balance">Browse Books</h1>
      <SearchFilters />
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {data?.items?.map((b) => (
          <BookCard key={b.id} book={b} />
        ))}
      </div>
      <div className="flex justify-center">
        <Pagination>
          <PaginationContent>
            {Array.from({ length: totalPages }).map((_, idx) => {
              const pageNum = idx + 1
              const p = new URLSearchParams(params.toString())
              p.set("page", String(pageNum))
              return (
                <PaginationItem key={pageNum}>
                  <PaginationLink href={`/books?${p.toString()}`} isActive={page === pageNum}>
                    {pageNum}
                  </PaginationLink>
                </PaginationItem>
              )
            })}
          </PaginationContent>
        </Pagination>
      </div>
    </div>
  )
}
