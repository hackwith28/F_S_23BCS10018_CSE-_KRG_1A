import Link from "next/link"
import useSWR from "swr"
import { jsonFetcher } from "@/lib/fetcher"
import type { Book, Paged } from "@/lib/types"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { BookCard } from "@/components/book-card"

export default function HomePage() {
  const { data } = useSWR<Paged<Book>>("/api/books?pageSize=4", jsonFetcher)

  return (
    <div className="grid gap-8">
      <section className="grid gap-4 text-center">
        <h1 className="text-3xl font-semibold text-balance">Welcome to the Digital Library</h1>
        <p className="text-muted-foreground text-pretty">
          Search, borrow, and manage books with a modern, accessible interface.
        </p>
        <div className="mx-auto flex w-full max-w-xl gap-2">
          <Input placeholder="Search books..." aria-label="Search books" />
          <Link href="/books">
            <Button>Browse</Button>
          </Link>
        </div>
      </section>

      <section className="grid gap-4">
        <h2 className="text-xl font-medium">Featured</h2>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {data?.items?.map((b) => (
            <BookCard key={b.id} book={b} />
          ))}
          {!data?.items?.length && (
            <Card>
              <CardContent className="p-6 text-muted-foreground">No featured books yet.</CardContent>
            </Card>
          )}
        </div>
      </section>
    </div>
  )
}
