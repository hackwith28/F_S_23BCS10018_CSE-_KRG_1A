"use client"

import Image from "next/image"
import Link from "next/link"
import type { Book } from "@/lib/types"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

export function BookCard({ book }: { book: Book }) {
  return (
    <Card className="h-full flex flex-col">
      <CardHeader>
        <CardTitle className="text-pretty">{book.title}</CardTitle>
      </CardHeader>
      <CardContent className="flex-1">
        <div className="flex gap-4">
          <div className="relative h-28 w-20 shrink-0 rounded-md border bg-card">
            <Image
              src={book.coverUrl || "/placeholder.svg?height=160&width=120&query=book%20cover"}
              alt={`${book.title} cover`}
              fill
              className="object-cover rounded-md"
            />
          </div>
          <div className="text-sm space-y-1">
            <p className="text-muted-foreground">Author: {book.author}</p>
            <p className="text-muted-foreground">Genre: {book.genre}</p>
            <p className="text-muted-foreground">Year: {book.year}</p>
            <div className="flex items-center gap-2">
              <Badge variant={book.isAvailable ? "secondary" : "outline"}>
                {book.isAvailable ? "Available" : "Checked out"}
              </Badge>
              {typeof book.ratingAvg === "number" && (
                <span aria-label="Average rating">★ {book.ratingAvg.toFixed(1)}</span>
              )}
            </div>
          </div>
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Link href={`/books/${book.id}`}>
          <Button size="sm">View</Button>
        </Link>
        <Link href={`/books/${book.id}`}>
          <Button size="sm" variant="outline">
            Borrow
          </Button>
        </Link>
      </CardFooter>
    </Card>
  )
}
