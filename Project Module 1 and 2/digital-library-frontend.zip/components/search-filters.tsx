"use client"

import { useRouter, useSearchParams } from "next/navigation"
import { useState, useEffect, useMemo } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"

const genres = ["All", "Fiction", "Non-Fiction", "Sci-Fi", "History", "Biography", "Technology"]
const languages = ["All", "English", "Hindi", "French", "German", "Spanish"]

export function SearchFilters() {
  const router = useRouter()
  const params = useSearchParams()
  const [q, setQ] = useState(params.get("q") || "")
  const [genre, setGenre] = useState(params.get("genre") || "All")
  const [language, setLanguage] = useState(params.get("language") || "All")
  const [available, setAvailable] = useState(params.get("available") || "Any")

  useEffect(() => {
    setQ(params.get("q") || "")
    setGenre(params.get("genre") || "All")
    setLanguage(params.get("language") || "All")
    setAvailable(params.get("available") || "Any")
  }, [params])

  const queryString = useMemo(() => {
    const p = new URLSearchParams()
    if (q) p.set("q", q)
    if (genre !== "All") p.set("genre", genre)
    if (language !== "All") p.set("language", language)
    if (available !== "Any") p.set("available", available)
    return p.toString()
  }, [q, genre, language, available])

  function apply() {
    router.push(`/books${queryString ? `?${queryString}` : ""}`)
  }

  function reset() {
    setQ("")
    setGenre("All")
    setLanguage("All")
    setAvailable("Any")
    router.push("/books")
  }

  return (
    <section aria-label="Search and filters" className="grid gap-4 rounded-lg border p-4">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
        <Label htmlFor="q" className="sr-only">
          Search books
        </Label>
        <Input
          id="q"
          placeholder="Search by title, author, ISBN..."
          value={q}
          onChange={(e) => setQ(e.target.value)}
          className="sm:flex-1"
        />
        <Button onClick={apply} className="sm:ml-2 mt-2 sm:mt-0">
          Search
        </Button>
        <Button onClick={reset} variant="outline" className="mt-2 sm:mt-0 bg-transparent">
          Reset
        </Button>
      </div>
      <Separator />
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <div className="grid gap-2">
          <Label>Genre</Label>
          <Select value={genre} onValueChange={setGenre}>
            <SelectTrigger>
              <SelectValue placeholder="Select genre" />
            </SelectTrigger>
            <SelectContent>
              {genres.map((g) => (
                <SelectItem key={g} value={g}>
                  {g}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="grid gap-2">
          <Label>Language</Label>
          <Select value={language} onValueChange={setLanguage}>
            <SelectTrigger>
              <SelectValue placeholder="Select language" />
            </SelectTrigger>
            <SelectContent>
              {languages.map((l) => (
                <SelectItem key={l} value={l}>
                  {l}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="grid gap-2">
          <Label>Availability</Label>
          <Select value={available} onValueChange={setAvailable}>
            <SelectTrigger>
              <SelectValue placeholder="Availability" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Any">Any</SelectItem>
              <SelectItem value="Available">Available</SelectItem>
              <SelectItem value="CheckedOut">Checked out</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
    </section>
  )
}
