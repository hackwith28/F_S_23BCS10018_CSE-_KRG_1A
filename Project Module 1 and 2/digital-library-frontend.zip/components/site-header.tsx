"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { useEffect, useState } from "react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"

type Role = "MEMBER" | "ADMIN"

export function SiteHeader() {
  const pathname = usePathname()
  const [role, setRole] = useState<Role>("MEMBER")

  useEffect(() => {
    const saved = window.localStorage.getItem("lms-role") as Role | null
    if (saved) setRole(saved)
  }, [])

  function updateRole(next: Role) {
    setRole(next)
    window.localStorage.setItem("lms-role", next)
  }

  const nav = [
    { href: "/", label: "Home" },
    { href: "/books", label: "Books" },
    { href: "/account", label: "Account" },
    { href: "/admin", label: "Admin" },
  ]

  return (
    <header className="sticky top-0 z-40 w-full border-b bg-background">
      <div className="container mx-auto flex h-14 items-center justify-between px-4">
        <Link href="/" className="font-semibold text-balance">
          Digital Library
        </Link>
        <nav className="flex items-center gap-4">
          {nav.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "text-sm transition-colors hover:text-primary",
                pathname === item.href ? "text-primary" : "text-muted-foreground",
              )}
            >
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          <Badge variant="secondary" className="hidden sm:inline-flex">
            Role: {role}
          </Badge>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" aria-label="Switch role">
                Switch Role
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>Current: {role}</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => updateRole("MEMBER")}>MEMBER</DropdownMenuItem>
              <DropdownMenuItem onClick={() => updateRole("ADMIN")}>ADMIN</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  )
}
