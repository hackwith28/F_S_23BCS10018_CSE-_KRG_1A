export type Role = "MEMBER" | "ADMIN"

export type Book = {
  id: number
  title: string
  author: string
  genre: string
  year: number
  isbn: string
  publisher: string
  isAvailable: boolean
  ratingAvg?: number
  coverUrl?: string
  language?: string
}

export type Review = {
  id: number
  bookId: number
  userId: number
  rating: number
  comment: string
  createdAt: string
}

export type Transaction = {
  id: number
  bookId: number
  cardId: number
  issueDate: string
  dueDate: string
  returnDate?: string
  fineAccrued?: number
}

export type Reservation = {
  id: number
  bookId: number
  cardId: number
  queuedAt: string
  fulfilledAt?: string
  canceledAt?: string
}

export type FinePolicy = {
  id: number
  userType: "MEMBER" | "ADMIN"
  itemType: "BOOK"
  rate: number
  gracePeriod: number
  maxFine: number
}

export type AccountSummary = {
  loans: Transaction[]
  reservations: Reservation[]
  finesDue: number
}

export type Paged<T> = {
  items: T[]
  total: number
  page: number
  pageSize: number
}

export type BookFilters = {
  q?: string
  genre?: string
  author?: string
  year?: string
  available?: string
  language?: string
}
